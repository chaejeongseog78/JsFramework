<?php
/**
 * Additional configuration applied when the variable "test" is added to the querystring.
 *
 * To test config options, place them in this file and add "&test" to your Minify URL.
 * Note that if this is on a public server, anyone can execute your test.
 * 
 * @package Minify
 */

